package com.company;
import java.util.Scanner;

public class TV {
    int channel;
    int volume;
    int wlaczyc;
}

